# Event Command Center — White-Label Edition

This is a config-driven version of the Event Command Center system.
The default configuration reproduces HIT FOR HIT BATTLES exactly as
it runs today — same colors, same checklist categories, same
Firebase project — so it also doubles as the working reference
deployment.

## What's in here

```
/brand.config.js          ← the only file you edit per brand
/index.html                Landing / reveal page
/Home/index.html           Flagship dashboard (checklists, countdown,
                            timeline, staff, alerts)
/STAFF/index.html          Staff clock-in / attendance roster
/STAFF/Manager/index.html  Artist manager & readiness checklist
/STAFF/ArtistCheckIn/      Day-of artist check-in board
/TEAM-CHECK-IN/index.html  Role-based team check-in + task board
/INTAKE/index.html         Artist & business intake questionnaire
```

Every page loads `/brand.config.js` before any other script, so
`window.BRAND` is guaranteed to exist by the time each page renders
or talks to Firebase.

## Spinning up a new brand

1. Duplicate this whole folder (e.g. `cp -r whitelabel new-brand`).
2. Open `brand.config.js` and edit:
   - **Identity** — `name`, `fullName`, `shortCode`, `tagline`,
     `poweredBy`, `slug`
   - **Contact/links** — `contactEmail`, `staffAttendanceEmail`,
     `website`, `instagram`, `youtubePlaylist`,
     `youtubePlaylistId`
   - **Colors** — the `colors` object. Every page maps its own local
     CSS variables onto this palette at load time via
     `BRAND.applyTheme()`, so this is the only place colors live.
   - **Checklist data** — `sections`, `timeline`, `battleSchedule`,
     `staffRoles`, `ideas` (Home dashboard)
3. Leave `firebase` as-is to share the existing project (see
   "Firebase: shared vs. separate" below), or paste in a new
   project's config if this brand needs full isolation.
4. Deploy the folder. Nothing else needs to change — every page
   reads brand name, colors, contact info, and checklist content
   from `brand.config.js` at runtime.

**INTAKE/index.html is the one exception worth knowing about:** the
structural bits (title, header, footer, section numbers, contact
email, video embed) are wired to config like everything else, but
the *questionnaire wording itself* ("Would you step into the
battle?", "This is your open mic," etc.) is marketing copy, not
data — rewrite it directly in the HTML per client, the same way
you'd rewrite ad copy. A `BRAND2FILL()` function near the bottom of
that file's `<script>` block fills in the handful of lines that do
reference the brand name dynamically.

## Firebase: shared vs. separate

**Current setup (default): one Firebase project, one room per
brand.** Every collection name is namespaced through
`BRAND.collection('team_tasks')` → `"h4h_team_tasks"` for this
brand, `"acme_team_tasks"` for the next one duplicated from this
folder. Fast to spin up a new client — just a new `slug` — but you
own and operate every brand's data in one place, and Firestore
security rules need to actually enforce that namespacing (see
below) so one client can't read or write another's collections.

**Alternative: a separate Firebase project per brand.** Fully
isolated — best if a client ever wants to own their own
hosting/billing, or if you want to hand off a deployment entirely.
More setup per client (new project, new config block, new deploy).
To switch a brand over, just replace that brand's `firebase: {...}`
block in its own `brand.config.js` with the new project's config —
no other code changes needed.

Given you're staying the operator for every brand right now, shared
project + per-brand room is the simpler path. Nothing above locks
you into it — moving a brand to its own project later is a one-line
config change per brand.

### Suggested Firestore rules (shared-project setup)

Namespacing collection *names* by brand slug prevents accidental
cross-brand reads in the app code, but it does not by itself stop
someone from hand-crafting a request to another brand's collection.
Lock that down with rules like:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Only allow access to collections that start with a known brand slug.
    match /{collection}/{doc} {
      allow read, write: if collection.matches('^(h4h)(_|-).*');
      // add each new brand's slug to the pattern as you launch it
    }
  }
}
```

Tighten further (auth-gated writes, per-room rules, etc.) before
handing a client-facing brand its own room in production — the
pattern above only prevents cross-brand collisions, it doesn't add
authentication.

## Pages not yet touched

The original repo also contained a `Team Check In` folder (legacy
V1/V2/V6 versions) and an `AUG6B1` one-off event page. Both were
dropped from this white-label pass since they're superseded/one-off
rather than part of the reusable system — pull them back in from the
original repo if you need that specific history.
