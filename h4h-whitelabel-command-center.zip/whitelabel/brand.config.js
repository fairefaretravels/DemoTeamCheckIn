/* ============================================================
   BRAND.CONFIG.JS
   ------------------------------------------------------------
   Single source of truth for one deployed instance of the
   Event Command Center system.

   TO WHITE-LABEL FOR A NEW CLIENT/BRAND:
   1. Duplicate this whole folder.
   2. Edit ONLY this file (name, colors, links, checklist data,
      Firebase collection prefix, event details).
   3. Deploy the folder. Nothing else needs to change.

   This file must load as a classic <script src="/brand.config.js">
   (NOT type="module") and must appear before any
   <script type="module"> tag on the page, so window.BRAND is
   guaranteed to exist before Firebase code runs.
   ============================================================ */

window.BRAND = {

  /* ---------------- IDENTITY ---------------- */
  name: "HIT FOR HIT",
  fullName: "HIT FOR HIT BATTLES™",
  shortCode: "H4H",
  tagline: "Independent Artist Battle Platform",
  poweredBy: "STV Radiomeltdown",
  poweredByFooter: "HIT FOR HIT BATTLES × STV RADIOMELTDOWN — Independent Artist Battle Platform",
  eyebrowTag: "ATLANTUCKY",

  /* Slug used to namespace every Firestore collection so multiple
     brands can safely share one Firebase project without colliding. */
  slug: "h4h",

  /* ---------------- CONTACT / LINKS ---------------- */
  contactEmail: "booking@radiomeltdown.online",
  staffAttendanceEmail: "H4Hbooking@radiomeltdown.online",
  website: "https://radiomeltdown.online",
  instagram: "https://www.instagram.com/hitforhitbattles/",
  youtubePlaylist: "https://youtube.com/playlist?list=PLa9auhfp7FjQ&si=8zW1ctkb1YTspBer",
  youtubePlaylistId: "PLa9auhfp7FjQ",

  /* ---------------- THEME ----------------
     Canonical palette. Every page maps its own local CSS variable
     names onto these via BRAND.applyTheme() at load time, so you
     only ever edit color values here. */
  colors: {
    bg:      "#0E0C10",   // page background / stage black
    panel:   "#1B181D",   // card / panel background
    panel2:  "#221E24",   // secondary panel / header strip
    line:    "#332E36",   // hairline borders
    text:    "#F1EEE9",   // primary text / chalk
    muted:   "#948F97",   // secondary text
    primary: "#E8283F",   // brand accent / "battle red"
    primaryDim: "#5A121C",
    gold:    "#F2B705",   // champion gold / highlight
    cyan:    "#35D6FF",   // live / info accent
    green:   "#55d98b",   // success / clocked-in
    danger:  "#ff4d4d"    // errors / remove actions
  },

  /* ---------------- FIREBASE ----------------
     Same project can serve many brands (see collection() helper
     below) — or swap in a brand-specific project here if a client
     ever needs fully isolated data/billing. */
  firebase: {
    apiKey: "AIzaSyDcynPbO4ci6DIb6QCn7G-rFKmxjp3ZmRU",
    authDomain: "hit-for-hit-events.firebaseapp.com",
    projectId: "hit-for-hit-events",
    storageBucket: "hit-for-hit-events.firebasestorage.app",
    messagingSenderId: "563307788704",
    appId: "1:563307788704:web:9b0d1adf39d7fab7444cc5",
    measurementId: "G-ZDC1S4LLZF"
  },

  /* Default event room / id — each page also lets an operator
     override this per-event via the room field / ?room= URL param. */
  defaultRoomId: "default-event",
  defaultEventId: "current",

  /* ---------------- COMMAND CENTER CHECKLISTS ---------------- */
  sections: [
    { id:'venue', icon:'🏟️', title:'Venue Setup', color:'battle-red', notes:true, items:[
      'Unlock venue','Set up registration table','Cover tables','Artist sign-in sheets','Guest sign-in',
      'Wristbands','VIP wristbands','Judges table','DJ table','Host microphone','Extension cords',
      'Power strips','Trash cans','Water for artists','Staff badges','Emergency kit'
    ]},
    { id:'door', icon:'🎟️', title:'Door Operations', color:'champion-gold', items:[
      'Cash box / change','Cash App QR','Square reader','Guest list','Stamp or wristband everyone',
      'Artist check-in','Vendor check-in','Security briefing'
    ]},
    { id:'stream', icon:'📡', title:'Live Streaming', color:'live-cyan', items:[
      'Internet speed test','Phone fully charged','Battery pack','Charging cables','Tripod','Gimbal',
      'Ring light','External microphone','Test Facebook Live','Test YouTube','Test brand stream',
      'Verify audio levels','Verify camera angle','Record backup copy','Test walkie-talkie page',
      'Test voting page','Backup hotspot ready'
    ]},
    { id:'dj', icon:'🎧', title:'DJ', color:'battle-red', items:[
      'Walk-in music','Artist intro music','Battle countdown','Intermission playlist','Winner music','Exit music'
    ]},
    { id:'content', icon:'📸', title:'Content Team', color:'champion-gold', items:[
      'Red carpet photos','Crowd shots','Artist interviews','Judge interviews','Behind-the-scenes',
      'Crowd reactions','Winner interview','Group photo'
    ]},
    { id:'merch', icon:'💰', title:'Merchandise', color:'live-cyan', items:[
      'Brand shirts','Event shirts','Hoodies','Stickers','Wristbands','Hats',
      'Artist CDs','QR code to website','QR code to voting','QR code to artist registration',
      'Business cards','Table banner','Price signs'
    ]},
    { id:'eon', icon:'🏁', title:'End of Night', color:'battle-red', items:[
      'Announce next event date','Collect judge sheets','Save voting results','Back up livestream',
      'Upload photos','Thank sponsors','Thank artists','Venue walkthrough','Collect trash',
      'Pack merchandise','Lock equipment','Team debrief'
    ]}
  ],

  // Minutes offset from DOORS OPEN (0 = doors open)
  timeline: [
    {off:-240, time:'3:00 PM', label:'Staff arrival & venue access'},
    {off:-225, time:'3:15 PM', label:'Tables, chairs, banners, registration'},
    {off:-180, time:'4:00 PM', label:'Audio setup'},
    {off:-150, time:'4:30 PM', label:'Streaming setup'},
    {off:-120, time:'5:00 PM', label:'Camera testing'},
    {off:-90,  time:'5:30 PM', label:'Artist check-in begins'},
    {off:-60,  time:'6:00 PM', label:'DJ sound check'},
    {off:-45,  time:'6:15 PM', label:'Host rehearsal'},
    {off:-30,  time:'6:30 PM', label:'Staff meeting'},
    {off:-15,  time:'6:45 PM', label:'Final walkthrough'},
    {off:0,    time:'7:00 PM', label:'Doors Open'},
    {off:0,    time:'7:00–8:00 PM', label:'Networking, music, interviews, audience arrival'},
    {off:50,   time:'7:50 PM', label:'Five-minute warning'},
    {off:60,   time:'8:00 PM', label:'Show Starts'},
    {off:240,  time:'11:00 PM', label:'Breakdown complete'}
  ],

  battleSchedule: [
    {off:60,  time:'8:00–8:10', label:'Welcome & Rules'},
    {off:70,  time:'8:10–8:30', label:'Battle 1'},
    {off:90,  time:'8:30–8:40', label:'Intermission'},
    {off:100, time:'8:40–9:00', label:'Battle 2'},
    {off:120, time:'9:00–9:10', label:'Intermission'},
    {off:130, time:'9:10–9:30', label:'Battle 3'},
    {off:150, time:'9:30–9:40', label:'Judges Final Deliberation'},
    {off:160, time:'9:40–9:50', label:'Crown Winners'},
    {off:170, time:'9:50–10:00', label:'Group Photos'},
    {off:180, time:'10:00 PM', label:'Networking / Meet & Greet'},
    {off:240, time:'11:00 PM', label:'Breakdown Complete'}
  ],

  staffRoles: [
    ['Event Director','Overall coordination'],
    ['Host','Keep show on schedule'],
    ['DJ','Music and battle transitions'],
    ['Door Manager','Admissions and wristbands'],
    ['Artist Coordinator','Check-in and lineup'],
    ['Stream Operator','Cameras and livestream'],
    ['Photographer','Photos and video'],
    ['Social Media','Live posts and updates'],
    ['Judges Coordinator','Score collection'],
    ['Merchandise Manager','Sales and inventory']
  ],

  ideas: [
    ['MERCH','Sell official branded merchandise — shirts, hoodies, hats, wristbands.'],
    ['QR TABLE','One QR table for: vote, register as an artist, join the mailing list, follow all socials.'],
    ['SPONSORS','Create a dedicated sponsor / vendor area.'],
    ['VIP','Offer VIP packages with reserved seating and exclusive merch.'],
    ['RECAP','Build a highlight reel before guests leave so they can relive the event immediately.'],
    ['MOMENTUM','Display a live countdown to the next qualifier event to keep momentum going.']
  ],

  /* ---------------- HELPERS ---------------- */

  // Namespaced Firestore collection/doc names so multiple brands can
  // safely share one Firebase project: BRAND.collection('team_checkins')
  // -> "h4h_team_checkins" for this brand, "acme_team_checkins" for another.
  collection(base){
    return this.slug + (base.startsWith('-') ? base : '_' + base);
  },

  // Injects this brand's palette into whatever local CSS variable
  // names a given page already uses, so page CSS never has to change.
  // map = { "--local-var-name": "colorKey", ... }
  applyTheme(map){
    const root = document.documentElement.style;
    for(const [cssVar, colorKey] of Object.entries(map)){
      if(this.colors[colorKey]) root.setProperty(cssVar, this.colors[colorKey]);
    }
  }
};
